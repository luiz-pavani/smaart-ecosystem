declare module 'react-youtube';
declare module 'jspdf-autotable';
declare module 'lucide-react';
declare module '@supabase/supabase-js';
